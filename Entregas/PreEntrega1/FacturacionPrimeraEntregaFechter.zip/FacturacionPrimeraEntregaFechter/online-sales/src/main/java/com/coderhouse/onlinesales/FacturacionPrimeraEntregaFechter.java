package com.coderhouse.onlinesales;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FacturacionPrimeraEntregaFechter {

	public static void main(String[] args) {
		SpringApplication.run(FacturacionPrimeraEntregaFechter.class, args);
	}

}
