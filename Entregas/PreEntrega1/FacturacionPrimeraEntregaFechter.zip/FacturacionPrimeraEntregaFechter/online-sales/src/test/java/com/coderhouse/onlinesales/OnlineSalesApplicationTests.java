package com.coderhouse.onlinesales;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineSalesApplicationTests {

	@Test
	void contextLoads() {
	}

}
