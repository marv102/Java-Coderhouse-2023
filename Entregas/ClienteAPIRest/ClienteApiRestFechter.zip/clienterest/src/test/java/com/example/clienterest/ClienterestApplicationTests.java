package com.example.clienterest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClienterestApplicationTests {

	@Test
	void contextLoads() {
	}

}
